/*
 *  jumphack.h
 *  SDLiPhoneOS
 *
 */

#ifndef _jumphack_h
#define _jumphack_h

#include "setjmp.h"

/* see SDL_uikitevents.m for more info */

extern jmp_buf *jump_env(void);

#endif

/* vi: set ts=4 sw=4 expandtab: */
