#pragma once

#include <stdint.h>

extern const uint8_t spu_soundmodule_bin[0x0000d471];
