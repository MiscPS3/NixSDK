#pragma once

#include <stdint.h>

extern const uint8_t vshader_text_normal_bin[0x00000e00];
