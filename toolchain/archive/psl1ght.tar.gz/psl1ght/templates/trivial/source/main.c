#include <stdio.h>

int main()
{
	printf("hello, ps3\n");
	return 0;
}	

