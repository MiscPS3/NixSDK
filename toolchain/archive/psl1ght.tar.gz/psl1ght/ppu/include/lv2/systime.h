#ifndef __LV2_SYSTIME_H__
#define __LV2_SYSTIME_H__

#include <ppu-types.h>

#ifdef __cplusplus
extern "C" {
#endif

s64 sysGetSystemTime();

#ifdef __cplusplus
	}
#endif

#endif
