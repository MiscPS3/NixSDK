#define LIBRARY_NAME		"cellSysmodule"
#define LIBRARY_SYMBOL		cellSysmodule

#define LIBRARY_HEADER_1	0x2c000001
#define LIBRARY_HEADER_2	0x0009
