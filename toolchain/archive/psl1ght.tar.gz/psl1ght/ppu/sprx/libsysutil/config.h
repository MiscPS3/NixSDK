#define LIBRARY_NAME		"cellSysutil"
#define LIBRARY_SYMBOL		cellSysutil

#define LIBRARY_HEADER_1	0x2c000001
#define LIBRARY_HEADER_2	0x0009
