#define LIBRARY_NAME		"cellResc"
#define LIBRARY_SYMBOL		cellResc

#define LIBRARY_HEADER_1	0x2c000001
#define LIBRARY_HEADER_2	0x0009
