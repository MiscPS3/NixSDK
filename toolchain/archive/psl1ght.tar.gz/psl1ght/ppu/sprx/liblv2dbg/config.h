#define LIBRARY_NAME		"sys_lv2dbg"
#define LIBRARY_SYMBOL		sys_lv2dbg

#define LIBRARY_HEADER_1	0x2c000001
#define LIBRARY_HEADER_2	0x0009
