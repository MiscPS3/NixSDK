#define LIBRARY_NAME		"cellGcmSys"
#define LIBRARY_SYMBOL		cellGcmSys

#define LIBRARY_HEADER_1	0x2c000001
#define LIBRARY_HEADER_2	0x0009
