#define LIBRARY_NAME		"cellHttp"
#define LIBRARY_SYMBOL		cellHttp

#define LIBRARY_HEADER_1	0x2c000001
#define LIBRARY_HEADER_2	0x0009
