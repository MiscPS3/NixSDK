#ifndef __EXPORTS_H__
#define __EXPORTS_H__

EXPORT(vdecClose, 0x16698e83);
EXPORT(vdecGetPicItem, 0x17c702b9);
EXPORT(vdecDecodeAu, 0x2bf4ddd2);
EXPORT(vdecGetPicture, 0x807c861a);
EXPORT(vdecEndSequence, 0x824433f0);
EXPORT(vdecOpen, 0xb6bbcd5d);
EXPORT(vdecStartSequence, 0xc757c2aa);
EXPORT(vdecQueryAttr, 0xff6f6ebe);

#endif
